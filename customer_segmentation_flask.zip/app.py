from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
from sklearn.cluster import KMeans

app = Flask(__name__)

# In-memory storage
customers_df = pd.DataFrame()

@app.route("/")
def dashboard():
    return render_template("dashboard.html")

@app.route("/upload", methods=["GET", "POST"])
def upload():
    global customers_df
    if request.method == "POST":
        file = request.files['file']
        if file and file.filename.endswith(".csv"):
            customers_df = pd.read_csv(file)
            return redirect(url_for("upload", success=len(customers_df)))
        return redirect(url_for("upload", error=1))
    return render_template("upload.html", success=request.args.get("success"), error=request.args.get("error"))

@app.route("/cluster")
def cluster():
    global customers_df
    if customers_df.empty:
        return render_template("clustering.html", error="No customer data available.")

    # Elbow method
    X = customers_df[['income', 'spending']]
    wcss = []
    for k in range(1, 11):
        kmeans = KMeans(n_clusters=k, random_state=0)
        kmeans.fit(X)
        wcss.append(kmeans.inertia_)

    # Apply clustering with k=6
    kmeans = KMeans(n_clusters=6, random_state=0)
    customers_df['cluster'] = kmeans.fit_predict(X)

    # Pass results to template
    cluster_counts = customers_df['cluster'].value_counts().sort_index().tolist()
    labels = [f"Cluster {i}" for i in range(len(cluster_counts))]
    scatter_data = customers_df[['income', 'spending', 'cluster']].to_dict(orient="records")

    return render_template("clustering.html",
                           wcss=wcss,
                           counts=cluster_counts,
                           labels=labels,
                           scatter_data=scatter_data,
                           customers=customers_df.to_dict(orient="records"))

if __name__ == "__main__":
    app.run(debug=True)
