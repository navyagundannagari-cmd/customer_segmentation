from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.metrics import silhouette_score

app = Flask(__name__)

# In-memory storage
customers_df = None


@app.route("/")
def dashboard():
    return render_template("dashboard.html")


@app.route("/upload", methods=["GET", "POST"])
def upload():
    global customers_df
    if request.method == "POST":
        file = request.files['file']
        if file and file.filename.endswith(".csv"):
            customers_df = pd.read_csv(file)

            # Normalize column names
            customers_df.columns = (
                customers_df.columns
                .str.strip()
                .str.lower()
                .str.replace(" ", "_")
                .str.replace(r"[\(\)\$-]", "", regex=True)
            )

            return redirect(url_for("upload", success=len(customers_df)))
        return redirect(url_for("upload", error=1))
    return render_template("upload.html", success=request.args.get("success"), error=request.args.get("error"))


@app.route("/cluster")
def cluster():
    global customers_df
    if customers_df is None:
        return render_template("clustering.html", error="No customer data uploaded yet!")

    try:
        # Which model? default=kmeans
        model_type = request.args.get("model", "kmeans")

        # Detect correct feature columns
        if {"income", "spending"}.issubset(customers_df.columns):
            X = customers_df[["income", "spending"]]
            income_col, spend_col = "income", "spending"
        elif {"annual_income_k", "spending_score_1100"}.issubset(customers_df.columns):
            X = customers_df[["annual_income_k", "spending_score_1100"]]
            income_col, spend_col = "annual_income_k", "spending_score_1100"
        else:
            return render_template(
                "clustering.html",
                error=f"CSV must have either ['income','spending'] or ['annual_income_k','spending_score_1100'], found {customers_df.columns.tolist()}"
            )

        # Elbow (for KMeans only)
        wcss = []
        if model_type == "kmeans":
            for k in range(1, 11):
                kmeans = KMeans(n_clusters=k, random_state=0)
                kmeans.fit(X)
                wcss.append(kmeans.inertia_)

        # ---- Apply chosen model ----
        if model_type == "kmeans":
            model = KMeans(n_clusters=6, random_state=0)
            cluster_labels = model.fit_predict(X)
        else:  # hierarchical
            model = AgglomerativeClustering(n_clusters=6)
            cluster_labels = model.fit_predict(X)

        customers_df["cluster"] = cluster_labels

        # Accuracy
        accuracy = silhouette_score(X, cluster_labels) if len(set(cluster_labels)) > 1 else 0

        # Bar chart data
        cluster_counts = customers_df["cluster"].value_counts().sort_index().tolist()
        labels = [f"Cluster {i}" for i in sorted(customers_df["cluster"].unique())]

        # Scatter data
        scatter_data = [
            {"income": row[income_col], "spending": row[spend_col], "cluster": int(row["cluster"])}
            for _, row in customers_df.iterrows()
        ]

        # Customer details
        customers = [
            {
                "customer_id": row.get("customer_id", ""),
                "age": row.get("age", ""),
                "gender": row.get("gender", ""),
                "income": row[income_col],
                "spending": row[spend_col],
                "cluster": int(row["cluster"])
            }
            for _, row in customers_df.iterrows()
        ]

        return render_template(
            "clustering.html",
            labels=labels,
            counts=cluster_counts,
            scatter_data=scatter_data,
            wcss=wcss if model_type == "kmeans" else None,
            customers=customers,
            accuracy=round(accuracy, 3),
            model_type=model_type
        )

    except Exception as e:
        return render_template("clustering.html", error=str(e))


@app.route("/compare")
def compare():
    global customers_df
    if customers_df is None:
        return render_template("comparison.html", error="No data uploaded yet!")

    try:
        # Detect feature columns
        if {"income", "spending"}.issubset(customers_df.columns):
            X = customers_df[["income", "spending"]]
        elif {"annual_income_k", "spending_score_1100"}.issubset(customers_df.columns):
            X = customers_df[["annual_income_k", "spending_score_1100"]]
        else:
            return render_template(
                "comparison.html",
                error=f"CSV must contain income & spending columns, found {customers_df.columns.tolist()}"
            )

        # ---- KMeans ----
        kmeans = KMeans(n_clusters=6, random_state=0)
        customers_df["kmeans_cluster"] = kmeans.fit_predict(X)
        kmeans_score = silhouette_score(X, customers_df["kmeans_cluster"])

        # ---- Hierarchical ----
        hier = AgglomerativeClustering(n_clusters=6)
        customers_df["hier_cluster"] = hier.fit_predict(X)
        hier_score = silhouette_score(X, customers_df["hier_cluster"])

        # ---- Cross-tab (confusion-like matrix) ----
        comparison_matrix = pd.crosstab(customers_df["kmeans_cluster"], customers_df["hier_cluster"])
        heatmap_data = comparison_matrix.values.tolist()
        heatmap_x = list(comparison_matrix.columns.astype(str))
        heatmap_y = list(comparison_matrix.index.astype(str))

        # 🔹 NEW: Save a heatmap PNG
        import matplotlib.pyplot as plt  # NEW
        import seaborn as sns           # NEW
        import os                       # NEW

        plt.figure(figsize=(6, 4))      # NEW
        sns.heatmap(comparison_matrix, annot=True, cmap="Blues", fmt="d")  # NEW
        os.makedirs("static", exist_ok=True)  # NEW
        heatmap_file = "confusion_heatmap.png"  # NEW
        plt.savefig(os.path.join("static", heatmap_file))  # NEW
        plt.close()  # NEW

        # Decide best
        if kmeans_score > hier_score:
            conclusion = "KMeans performs better"
        elif hier_score > kmeans_score:
            conclusion = "Hierarchical performs better"
        else:
            conclusion = "Both perform equally well"

        # ---- Classification reports ----
        from sklearn.metrics import classification_report
        kmeans_report = classification_report(customers_df["hier_cluster"], customers_df["kmeans_cluster"], output_dict=True)
        hier_report = classification_report(customers_df["kmeans_cluster"], customers_df["hier_cluster"], output_dict=True)

        return render_template("comparison.html",
                               kmeans_score=round(kmeans_score,3),
                               hier_score=round(hier_score,3),
                               conclusion=conclusion,
                               heatmap_data=heatmap_data,
                               heatmap_x=heatmap_x,
                               heatmap_y=heatmap_y,
                               kmeans_report=kmeans_report,
                               hier_report=hier_report,
                               heatmap_file=heatmap_file)   # NEW

    except Exception as e:
        return render_template("comparison.html", error=str(e))




if __name__ == "__main__":
    app.run(debug=True)
