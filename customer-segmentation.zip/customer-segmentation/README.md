
# Customer Segmentation (React + FastAPI)

## Quick Start

1. **Unzip** this archive.
2. Open a terminal in the root folder and run:

```bash
npm install
```

This will:
- install **client** dependencies (React, Vite, Chart.js, etc.)
- create a **Python virtual environment** in `server/.venv`
- install **FastAPI** + data-science packages into that venv

3. Start both servers (API + Web UI):

```bash
npm run dev
```

- Web UI: http://localhost:5173
- API:     http://localhost:8000

Upload a CSV with columns like `CustomerID, Age, Gender, AnnualIncome, SpendingScore`, pick features & K, and run clustering. Download labeled CSV from the results section.

> If Python is not detected during `npm install`, you'll see a note in the console. Install Python 3.9+ and then run the commands shown to set up the venv manually.

## Notes
- The scatter plot uses the **first two selected features** as X/Y axes.
- Large datasets are down-sampled to ~1500 points for plotting.
- Labeled CSV adds a `_cluster` column; rows with missing selected features are left unlabeled (NaN).

## Scripts
- `npm run dev` – runs FastAPI (with `uvicorn --reload`) and Vite dev server concurrently.
- `npm run build` – builds the React app.
- `npm run preview` – serves the built React app for a quick preview.
