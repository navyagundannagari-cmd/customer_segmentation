
import axios from "axios";

const API = axios.create({ baseURL: "http://localhost:8000", timeout: 60000 });

export async function runClustering({ file, k, features, normalize, init }) {
  const form = new FormData();
  form.append("file", file);
  form.append("k", String(k));
  features.forEach((f) => form.append("features", f));
  form.append("normalize", normalize ? "true" : "false");
  form.append("init", init);
  const { data } = await API.post("/cluster", form, { headers: { "Content-Type": "multipart/form-data" } });
  return data;
}

export function buildDownloadUrl(path) {
  return `http://localhost:8000${path}`;
}
