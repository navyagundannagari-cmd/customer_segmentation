
import { useState } from "react";
import Papa from "papaparse";
import { runClustering, buildDownloadUrl } from "./services/api";
import ScatterPlot from "./components/ScatterPlot";
import "./app.css";

export default function App() {
  const [file, setFile] = useState(null);
  const [headers, setHeaders] = useState([]);
  const [preview, setPreview] = useState([]);
  const [selectedFeatures, setSelectedFeatures] = useState(["AnnualIncome", "SpendingScore"]);
  const [k, setK] = useState(6);
  const [normalize, setNormalize] = useState(true);
  const [init, setInit] = useState("k-means++");

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  function onFileChange(e) {
    const f = e.target.files[0];
    setFile(f);
    setResult(null);
    setError("");

    if (!f) return;
    Papa.parse(f, {
      header: true,
      preview: 50,
      skipEmptyLines: true,
      complete: (res) => {
        setHeaders(res.meta.fields || []);
        setPreview(res.data || []);
        if (res.meta.fields?.length) {
          if (!["AnnualIncome", "SpendingScore"].every(x => res.meta.fields.includes(x))) {
            setSelectedFeatures(res.meta.fields.slice(0, 2));
          }
        }
      },
      error: (err) => setError(`CSV parse error: ${err.message}`),
    });
  }

  async function onRun() {
    if (!file) { setError("Please select a CSV file."); return; }
    if (!selectedFeatures.length) { setError("Select at least one feature."); return; }

    setLoading(true);
    setError("");
    try {
      const data = await runClustering({ file, k, features: selectedFeatures, normalize, init });
      setResult(data);
    } catch (e) {
      setError(e?.response?.data?.detail || e.message || "Server error");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="app">
      <header className="header">
        <h1>Customer Segmentation (K-Means)</h1>
        <p className="muted">Upload CSV → Choose features → Pick K → Cluster</p>
      </header>

      <main className="container">
        <section className="card">
          <h2>1) Upload CSV</h2>
          <input type="file" accept=".csv" onChange={onFileChange} />
          <small className="muted">
            Suggested columns: <code>CustomerID, Age, Gender, AnnualIncome, SpendingScore</code>
          </small>
        </section>

        <section className="card">
          <h2>2) Configure</h2>
          <div className="grid">
            <div>
              <label>K (clusters): {k}</label>
              <input type="range" min="2" max="10" value={k} onChange={e => setK(+e.target.value)} />
            </div>
            <div>
              <label>Features (select 2 for scatter)</label>
              <select multiple size="6" value={selectedFeatures} onChange={(e) => {
                const opts = Array.from(e.target.selectedOptions).map(o => o.value);
                setSelectedFeatures(opts);
              }}>
                {headers.map(h => (<option key={h} value={h}>{h}</option>))}
              </select>
              <small className="muted">At least 1 numeric. For plotting, first two are used.</small>
            </div>
            <div>
              <label>Normalize features</label>
              <input type="checkbox" checked={normalize} onChange={e => setNormalize(e.target.checked)} />
            </div>
            <div>
              <label>Initialization</label>
              <select value={init} onChange={(e)=>setInit(e.target.value)}>
                <option value="k-means++">k-means++</option>
                <option value="random">random</option>
              </select>
            </div>
          </div>

          <div style={{ marginTop: 12 }}>
            <button className="btn primary" onClick={onRun} disabled={loading}>
              {loading ? "Clustering..." : "Run Clustering"}
            </button>
            {error && <span className="error">{error}</span>}
          </div>
        </section>

        <section className="card">
          <h2>3) CSV Preview (first 50 rows)</h2>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>{headers.map(h => <th key={h}>{h}</th>)}</tr>
              </thead>
              <tbody>
                {preview.map((r, i) => (
                  <tr key={i}>
                    {headers.map(h => <td key={h}>{r[h]}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
            {!file && <div className="muted">No file selected yet.</div>}
          </div>
        </section>

        {result && (
          <>
            <section className="card">
              <h2>4) Results</h2>
              <div className="meta">
                <div><b>K</b><div>{result.k}</div></div>
                <div><b>Features</b><div>{result.features.join(", ")}</div></div>
                <div><b>Normalize</b><div>{result.normalize ? "Yes" : "No"}</div></div>
                <div><b>Silhouette</b><div>{result.silhouette ?? "—"}</div></div>
                <div><b>Total points (sampled for plot)</b><div>{result.points.length}</div></div>
              </div>

              <div style={{ marginTop: 16 }}>
                <ScatterPlot
                  points={result.points}
                  centroids={result.clusters.map(c => c.centroid)}
                  features={result.features}
                  clusters={result.clusters}
                />
              </div>
            </section>

            <section className="card">
              <h2>5) Cluster Summaries</h2>
              <div className="cards">
                {result.clusters.map((c) => (
                  <div className="cluster-card" key={c.id}>
                    <h3>Cluster {c.id}</h3>
                    <ul>
                      <li><b>Size:</b> {c.size}</li>
                      <li><b>Centroid {result.features[0]}:</b> {Number(c.centroid[result.features[0]]).toFixed(2)}</li>
                      <li><b>Centroid {result.features[1]]}:</b> {Number(c.centroid[result.features[1]]).toFixed(2)}</li>
                    </ul>
                    <p className="muted">Add persona notes here (e.g., "High Income, High Spend").</p>
                  </div>
                ))}
              </div>
            </section>

            <section className="card actions">
              <a className="btn secondary" href={buildDownloadUrl(result.downloadUrl)}>
                Download Labeled CSV
              </a>
            </section>
          </>
        )}
      </main>

      <footer className="footer">
        <small>© {new Date().getFullYear()} Customer Analytics UI</small>
      </footer>
    </div>
  );
}
