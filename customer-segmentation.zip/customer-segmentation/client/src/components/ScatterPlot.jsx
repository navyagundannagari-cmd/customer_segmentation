
import { Scatter } from "react-chartjs-2";
import { Chart as ChartJS, LinearScale, PointElement, Tooltip, Legend } from "chart.js";

ChartJS.register(LinearScale, PointElement, Tooltip, Legend);

const palette = ["#6366F1", "#22D3EE", "#F472B6", "#F59E0B", "#10B981", "#EF4444", "#3B82F6", "#A78BFA", "#F97316", "#84CC16"];

export default function ScatterPlot({ points, features, centroids, clusters }) {
  const [xKey, yKey] = features;
  const byCluster = {};
  points.forEach(p => { (byCluster[p.cluster] ||= []).push({ x: p.x, y: p.y }); });

  const datasets = Object.keys(byCluster).map((cid, i) => ({
    label: `Cluster ${cid} (n=${clusters.find(c=>c.id===+cid)?.size ?? "?"})`,
    data: byCluster[cid],
    backgroundColor: palette[i % palette.length],
    pointRadius: 3
  }));

  if (centroids?.length) {
    datasets.push({
      label: "Centroids",
      type: "bubble",
      data: centroids.map(c => ({ x: c[xKey], y: c[yKey], r: 6 })),
      backgroundColor: centroids.map((_, i) => `${palette[i % palette.length]}33`),
      borderColor: centroids.map((_, i) => palette[i % palette.length]),
      borderWidth: 2
    });
  }

  return (
    <div style={{ background: "#0b1220", padding: "12px", borderRadius: 8 }}>
      <Scatter
        data={{ datasets }}
        options={{
          responsive: true,
          plugins: { legend: { position: "bottom", labels: { color: "#e7ecf3" } } },
          scales: {
            x: { title: { display: true, text: xKey, color: "#e7ecf3" }, ticks: { color: "#e7ecf3" }, grid: { color: "#22304f" } },
            y: { title: { display: true, text: yKey, color: "#e7ecf3" }, ticks: { color: "#e7ecf3" }, grid: { color: "#22304f" } },
          },
        }}
      />
    </div>
  );
}
