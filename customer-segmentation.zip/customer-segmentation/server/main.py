from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from typing import List, Dict, Any
import pandas as pd
import numpy as np
import os
import io
import uuid
from datetime import datetime
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

app = FastAPI(title="Customer Segmentation API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

JOB_STORE: Dict[str, Dict[str, Any]] = {}
DOWNLOAD_DIR = os.path.join(os.path.dirname(__file__), "downloads")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

def _parse_csv(file: UploadFile) -> pd.DataFrame:
    contents = file.file.read()
    file.file.seek(0)
    try:
        buf = io.BytesIO(contents)
        try:
            df = pd.read_csv(buf)
        except UnicodeDecodeError:
            buf.seek(0)
            df = pd.read_csv(buf, encoding="latin-1")
        return df
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"CSV parse error: {e}")

def _validate_features(df: pd.DataFrame, features: List[str]) -> List[str]:
    features = [f for f in features if f in df.columns]
    if not features:
        raise HTTPException(status_code=400, detail="No valid feature columns found in CSV.")
    numeric = df[features].select_dtypes(include=[np.number]).columns.tolist()
    if not numeric:
        raise HTTPException(status_code=400, detail="Selected features are not numeric.")
    return numeric

def _limit_points_for_plot(points: pd.DataFrame, max_points:int=1500) -> pd.DataFrame:
    if len(points) <= max_points:
        return points
    return points.sample(n=max_points, random_state=42)

@app.post("/cluster")
async def cluster(
    file: UploadFile = File(...),
    k: int = Form(..., ge=2, le=20),
    features: List[str] = Form(...),
    normalize: bool = Form(True),
    init: str = Form("k-means++")
):
    if init not in ("k-means++", "random"):
        raise HTTPException(status_code=400, detail="init must be 'k-means++' or 'random'.")

    df = _parse_csv(file)
    cols = _validate_features(df, features)

    work = df[cols].copy()
    mask_valid = work.dropna().index
    if len(mask_valid) < 2:
        raise HTTPException(status_code=400, detail="Not enough valid rows after removing missing values.")

    work = work.loc[mask_valid]

    scaler = None
    X = work.values
    if normalize:
        scaler = StandardScaler()
        X = scaler.fit_transform(X)

    try:
        km = KMeans(
            n_clusters=k,
            init=init,
            n_init="auto" if hasattr(KMeans(), "n_init") else 10,
            random_state=42
        )
        labels = km.fit_predict(X)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"KMeans failed: {e}")

    centers = km.cluster_centers_
    if scaler is not None:
        centers = scaler.inverse_transform(centers)
    centroids = [dict(zip(cols, map(float, c))) for c in centers]

    try:
        sil = float(silhouette_score(X, labels)) if k > 1 and len(work) > k else None
    except Exception:
        sil = None

    labeled = df.copy()
    labeled["_cluster"] = np.nan
    labeled.loc[work.index, "_cluster"] = labels

    plots = []
    points_for_plot_total = pd.DataFrame()
    for cid in range(k):
        idx = np.where(labels == cid)[0]
        cluster_rows = work.iloc[idx].copy()
        size = int(cluster_rows.shape[0])
        cluster_rows["_cluster"] = cid
        points_for_plot_total = pd.concat([points_for_plot_total, cluster_rows], axis=0)
        plots.append({"id": cid, "size": size, "centroid": centroids[cid]})

    points_for_plot_total = _limit_points_for_plot(points_for_plot_total)

    job_id = f"{datetime.now().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:8]}"
    out_path = os.path.join(DOWNLOAD_DIR, f"{job_id}.csv")
    labeled.to_csv(out_path, index=False)

    JOB_STORE[job_id] = {"path": out_path, "meta": {"k": k, "features": cols, "normalize": normalize, "silhouette": sil, "centroids": centroids}}

    x_key, y_key = (cols[0], cols[1] if len(cols) > 1 else cols[0])
    points_payload = []
    for _, row in points_for_plot_total.iterrows():
        pt = {"x": float(row[x_key]), "y": float(row[y_key]), "cluster": int(row["_cluster"])}
        points_payload.append(pt)

    sizes = pd.Series(labels).value_counts().to_dict()
    for c in plots:
        c["size"] = int(sizes.get(c["id"], 0))

    return JSONResponse({
        "jobId": job_id,
        "k": k,
        "features": [x_key, y_key],
        "normalize": normalize,
        "silhouette": sil,
        "clusters": plots,
        "points": points_payload,
        "downloadUrl": f"/download/{job_id}"
    })

@app.get("/download/{job_id}")
async def download(job_id: str):
    item = JOB_STORE.get(job_id)
    if not item:
        raise HTTPException(status_code=404, detail="Job not found")
    path = item["path"]
    if not os.path.exists(path):
        raise HTTPException(status_code=410, detail="File expired")
    return FileResponse(path, media_type="text/csv", filename=f"labeled_{job_id}.csv")
