// Run FastAPI using the venv python
import { spawn } from 'node:child_process';
import path from 'node:path';
import { existsSync } from 'node:fs';

const serverDir = path.join('server');
const venvDir = path.join(serverDir, '.venv');
const pyPath = process.platform === 'win32'
  ? path.join(venvDir, 'Scripts', 'python.exe')
  : path.join(venvDir, 'bin', 'python');

function fallbackPython() {
  return process.platform === 'win32' ? 'py' : 'python3';
}

const py = existsSync(pyPath) ? pyPath : fallbackPython();

const args = ['-m', 'uvicorn', 'main:app', '--reload', '--port', '8000'];
const child = spawn(py, args, { stdio: 'inherit', cwd: serverDir, env: process.env });
child.on('exit', (code) => process.exit(code ?? 0));
