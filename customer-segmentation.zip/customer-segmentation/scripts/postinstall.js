// Postinstall: install client deps and setup Python venv for API
import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';

function run(cmd, args, opts={}) {
  const res = spawnSync(cmd, args, { stdio: 'inherit', shell: false, ...opts });
  if (res.status !== 0) {
    throw new Error(`${cmd} ${args.join(' ')} failed with code ${res.status}`);
  }
}

// 1) install client dependencies
console.log('\n[postinstall] Installing client dependencies...');
run(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['install'], { cwd: path.join('client') });

// 2) Setup Python venv and install requirements
console.log('\n[postinstall] Setting up Python virtual environment for API...');
const serverDir = path.join('server');
const venvDir = path.join(serverDir, '.venv');

function findPython() {
  const candidates = process.platform === 'win32'
    ? ['py', 'python', 'python3']
    : ['python3', 'python'];
  for (const c of candidates) {
    const r = spawnSync(c, ['--version'], { stdio: 'ignore' });
    if (r.status === 0) return c;
  }
  return null;
}

const py = findPython();
if (!py) {
  console.warn('[postinstall] Python not found. Please install Python 3.9+ and run:');
  console.warn('  python -m venv server/.venv && server/.venv/bin/pip install -r server/requirements.txt');
  process.exit(0);
}

if (!existsSync(venvDir)) {
  console.log('[postinstall] Creating venv...');
  run(py, ['-m', 'venv', '.venv'], { cwd: serverDir });
}

// Determine pip path inside venv
const pipPath = process.platform === 'win32'
  ? path.join(venvDir, 'Scripts', 'pip.exe')
  : path.join(venvDir, 'bin', 'pip');

console.log('[postinstall] Installing server requirements via venv pip...');
run(pipPath, ['install', '-r', 'requirements.txt'], { cwd: serverDir });

console.log('\n[postinstall] Done. Use:');
console.log('  npm run dev');
