package com.segmentation.controller;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.segmentation.util.DBConnection;
import com.segmentation.model.Customer;

@WebServlet("/ClusterServlet")
public class ClusterServlet extends HttpServlet {

    private static class Centroid {
        double income;
        double spending;
        Centroid(double income, double spending) { this.income = income; this.spending = spending; }
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        int K = 6; // default
        try {
            if (req.getParameter("k") != null) {
                K = Math.max(1, Integer.parseInt(req.getParameter("k")));
            }
        } catch (Exception ignored) {}

        try {
            Connection conn = DBConnection.getConnection();
            List<Customer> customers = new ArrayList<>();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT id, customer_id, age, gender, income, spending, COALESCE(cluster, -1) as cluster FROM customers");
            while (rs.next()) {
                customers.add(new Customer(
                    rs.getInt("id"),
                    rs.getInt("customer_id"),
                    rs.getInt("age"),
                    rs.getString("gender"),
                    rs.getDouble("income"),
                    rs.getDouble("spending"),
                    rs.getInt("cluster")
                ));
            }
            if (customers.isEmpty()) {
                res.sendRedirect("clustering.jsp?msg=No+customers+found.+Upload+CSV+first.");
                return;
            }

            // Initialize centroids: pick K random customers
            Random rand = new Random(42);
            List<Centroid> centroids = new ArrayList<>();
            Set<Integer> chosen = new HashSet<>();
            while (centroids.size() < K && centroids.size() < customers.size()) {
                int idx = rand.nextInt(customers.size());
                if (chosen.add(idx)) {
                    Customer c = customers.get(idx);
                    centroids.add(new Centroid(c.income, c.spending));
                }
            }

            boolean changed = true;
            int maxIters = 100;
            int iter = 0;
            int[] assignment = new int[customers.size()];
            Arrays.fill(assignment, -1);

            while (changed && iter < maxIters) {
                changed = false;
                iter++;

                // Assign step
                for (int i = 0; i < customers.size(); i++) {
                    Customer c = customers.get(i);
                    int bestK = 0;
                    double bestDist = Double.MAX_VALUE;
                    for (int k = 0; k < centroids.size(); k++) {
                        double dx = c.income - centroids.get(k).income;
                        double dy = c.spending - centroids.get(k).spending;
                        double dist = dx*dx + dy*dy;
                        if (dist < bestDist) {
                            bestDist = dist;
                            bestK = k;
                        }
                    }
                    if (assignment[i] != bestK) {
                        assignment[i] = bestK;
                        changed = true;
                    }
                }

                // Update step
                double[] sumX = new double[centroids.size()];
                double[] sumY = new double[centroids.size()];
                int[] counts = new int[centroids.size()];
                for (int i = 0; i < customers.size(); i++) {
                    int k = assignment[i];
                    sumX[k] += customers.get(i).income;
                    sumY[k] += customers.get(i).spending;
                    counts[k]++;
                }
                for (int k = 0; k < centroids.size(); k++) {
                    if (counts[k] > 0) {
                        centroids.get(k).income = sumX[k] / counts[k];
                        centroids.get(k).spending = sumY[k] / counts[k];
                    }
                }
            }

            // Persist cluster assignments
            PreparedStatement ps = conn.prepareStatement("UPDATE customers SET cluster=? WHERE id=?");
            for (int i = 0; i < customers.size(); i++) {
                ps.setInt(1, assignment[i]);
                ps.setInt(2, customers.get(i).id);
                ps.addBatch();
            }
            ps.executeBatch();

            res.sendRedirect("clustering.jsp?updated=" + customers.size());
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
