package com.segmentation.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.segmentation.util.DBConnection;

@WebServlet("/UploadServlet")
@MultipartConfig
public class UploadServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        Part filePart = req.getPart("file");
        if (filePart == null) {
            res.sendRedirect("upload.jsp?error=1");
            return;
        }
        try (InputStream is = filePart.getInputStream();
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            Connection conn = DBConnection.getConnection();
            conn.setAutoCommit(false);
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO customers(customer_id, age, gender, income, spending, cluster) VALUES (?,?,?,?,?,NULL)"
            );

            String line;
            boolean headerSkipped = false;
            int count = 0;
            while ((line = br.readLine()) != null) {
                if (!headerSkipped) { headerSkipped = true; continue; } // skip header
                String[] parts = line.split(",");
                if (parts.length < 5) continue;
                int customerId = Integer.parseInt(parts[0].trim());
                int age = Integer.parseInt(parts[1].trim());
                String gender = parts[2].trim();
                double income = Double.parseDouble(parts[3].trim());
                double spending = Double.parseDouble(parts[4].trim());
                ps.setInt(1, customerId);
                ps.setInt(2, age);
                ps.setString(3, gender);
                ps.setDouble(4, income);
                ps.setDouble(5, spending);
                ps.addBatch();
                count++;
            }
            ps.executeBatch();
            conn.commit();
            res.sendRedirect("upload.jsp?success=" + count);
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
