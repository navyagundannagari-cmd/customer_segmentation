package com.segmentation.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.segmentation.util.DBConnection;

@WebServlet("/DeleteAllServlet")
public class DeleteAllServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        try (Connection conn = DBConnection.getConnection()) {
            Statement st = conn.createStatement();
            st.executeUpdate("TRUNCATE TABLE customers");  // clears all rows
            res.sendRedirect("dashboard.jsp?msg=All customers deleted successfully.");
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
