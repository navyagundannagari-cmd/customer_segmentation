package com.segmentation.util;
import java.sql.*;

public class DBConnection {
    private static Connection conn = null;

    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        if (conn == null || conn.isClosed()) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/segmentationdb?useSSL=false&allowPublicKeyRetrieval=true",
                "root",
                "Jatin@2004"
            );
        }
        return conn;
    }
}
