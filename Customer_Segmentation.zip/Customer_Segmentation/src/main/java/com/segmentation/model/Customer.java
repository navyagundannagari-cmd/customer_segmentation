package com.segmentation.model;

public class Customer {
    public int id;
    public int customerId;
    public int age;
    public String gender;
    public double income;
    public double spending;
    public int cluster;

    public Customer(int id, int customerId, int age, String gender, double income, double spending, int cluster) {
        this.id = id;
        this.customerId = customerId;
        this.age = age;
        this.gender = gender;
        this.income = income;
        this.spending = spending;
        this.cluster = cluster;
    }
}
