package com.segmentation.controller;

import com.segmentation.model.Customer;
import com.segmentation.storage.CustomerStore;

import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;

@WebServlet("/UploadServlet")
@MultipartConfig
public class UploadServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        Part filePart = req.getPart("file");
        if (filePart == null) {
            res.sendRedirect("upload.jsp?error=1");
            return;
        }

        try (InputStream is = filePart.getInputStream();
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            CustomerStore.clear();
            String line;
            boolean headerSkipped = false;
            int count = 0;
            while ((line = br.readLine()) != null) {
                if (!headerSkipped) { headerSkipped = true; continue; } // skip header
                String[] parts = line.split(",");
                if (parts.length < 5) continue;
                int customerId = Integer.parseInt(parts[0].trim());
                int age = Integer.parseInt(parts[1].trim());
                String gender = parts[2].trim();
                double income = Double.parseDouble(parts[3].trim());
                double spending = Double.parseDouble(parts[4].trim());
                CustomerStore.addCustomer(new Customer(customerId, age, gender, income, spending));
                count++;
            }
            res.sendRedirect("upload.jsp?success=" + count);
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
