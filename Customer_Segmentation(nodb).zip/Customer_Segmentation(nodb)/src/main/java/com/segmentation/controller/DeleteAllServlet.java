package com.segmentation.controller;

import com.segmentation.storage.CustomerStore;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/DeleteAllServlet")
public class DeleteAllServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        CustomerStore.clear();
        res.sendRedirect("dashboard.jsp?deleted=1");
    }
}
