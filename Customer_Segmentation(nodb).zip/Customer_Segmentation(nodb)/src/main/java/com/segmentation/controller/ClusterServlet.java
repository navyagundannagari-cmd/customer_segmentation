package com.segmentation.controller;

import com.segmentation.model.Customer;
import com.segmentation.storage.CustomerStore;
import com.segmentation.util.KMeans;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.*;

@WebServlet("/ClusterServlet")
public class ClusterServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Customer> customers = CustomerStore.getCustomers();

        if (customers.isEmpty()) {
            request.setAttribute("error", "No customer data available.");
            request.getRequestDispatcher("clustering.jsp").forward(request, response);
            return;
        }

        // Elbow method (WCSS values for k=1..10)
        List<Double> wcssValues = new ArrayList<>();
        for (int k = 1; k <= 10; k++) {
            List<Customer> temp = new ArrayList<>();
            for (Customer c : customers) {
                temp.add(new Customer(c.getCustomerId(), c.getAge(), c.getGender(), c.getIncome(), c.getSpending()));
            }
            List<double[]> centroids = KMeans.runKMeans(temp, k, 100);
            wcssValues.add(KMeans.calculateWCSS(temp, centroids));
        }

        // Final clustering with k=6
        KMeans.runKMeans(customers, 6, 100);

        request.setAttribute("wcssValues", wcssValues);
        request.setAttribute("customers", customers);
        request.getRequestDispatcher("clustering.jsp").forward(request, response);
    }
}

