package com.segmentation.storage;

import com.segmentation.model.Customer;
import java.util.*;

public class CustomerStore {
    private static final List<Customer> customers = new ArrayList<>();

    public static void addCustomer(Customer c) { customers.add(c); }
    public static List<Customer> getCustomers() { return customers; }
    public static void clear() { customers.clear(); }
}
