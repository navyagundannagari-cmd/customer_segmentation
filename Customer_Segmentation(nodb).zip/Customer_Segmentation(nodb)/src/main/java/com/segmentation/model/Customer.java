package com.segmentation.model;

public class Customer {
    private int customerId;
    private int age;
    private String gender;
    private double income;
    private double spending;
    private Integer cluster;

    public Customer(int customerId, int age, String gender, double income, double spending) {
        this.customerId = customerId;
        this.age = age;
        this.gender = gender;
        this.income = income;
        this.spending = spending;
    }

    public int getCustomerId() { return customerId; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
    public double getIncome() { return income; }
    public double getSpending() { return spending; }
    public Integer getCluster() { return cluster; }
    public void setCluster(Integer cluster) { this.cluster = cluster; }
}
