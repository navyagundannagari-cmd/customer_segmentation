package com.segmentation.util;

import com.segmentation.model.Customer;
import java.util.*;

public class KMeans {

    public static List<double[]> runKMeans(List<Customer> customers, int k, int maxIter) {
        Random rand = new Random();
        List<double[]> centroids = new ArrayList<>();

        // Initialize centroids randomly
        for (int i = 0; i < k; i++) {
            Customer c = customers.get(rand.nextInt(customers.size()));
            centroids.add(new double[]{c.getIncome(), c.getSpending()});
        }

        for (int iter = 0; iter < maxIter; iter++) {
            // Assign clusters
            for (Customer c : customers) {
                double minDist = Double.MAX_VALUE;
                int cluster = 0;
                for (int i = 0; i < centroids.size(); i++) {
                    double[] center = centroids.get(i);
                    double dist = Math.pow(c.getIncome() - center[0], 2) + Math.pow(c.getSpending() - center[1], 2);
                    if (dist < minDist) {
                        minDist = dist;
                        cluster = i;
                    }
                }
                c.setCluster(cluster);
            }

            // Recalculate centroids
            double[][] sums = new double[k][2];
            int[] counts = new int[k];
            for (Customer c : customers) {
                int cl = c.getCluster();
                sums[cl][0] += c.getIncome();
                sums[cl][1] += c.getSpending();
                counts[cl]++;
            }

            for (int i = 0; i < k; i++) {
                if (counts[i] > 0) {
                    centroids.set(i, new double[]{sums[i][0] / counts[i], sums[i][1] / counts[i]});
                }
            }
        }

        return centroids;
    }

    // Calculate WCSS
    public static double calculateWCSS(List<Customer> customers, List<double[]> centroids) {
        double wcss = 0.0;
        for (Customer c : customers) {
            int cluster = c.getCluster();
            double[] center = centroids.get(cluster);
            wcss += Math.pow(c.getIncome() - center[0], 2) + Math.pow(c.getSpending() - center[1], 2);
        }
        return wcss;
    }
}
